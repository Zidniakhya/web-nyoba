<template lang="pug">
.slide-transition
  h1 Subscibe to weekly Vue.js News
  SubscribeContent
</template>

<script>
import SubscribeContent from '@/components/SubscribeContent'

export default {
  components: { SubscribeContent }
}
</script>

<style lang="sass">
</style>
