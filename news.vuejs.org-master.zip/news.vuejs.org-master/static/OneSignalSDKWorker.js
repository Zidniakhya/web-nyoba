importScripts('/sw.js', '/_nuxt/ons.40ac840e.js')
